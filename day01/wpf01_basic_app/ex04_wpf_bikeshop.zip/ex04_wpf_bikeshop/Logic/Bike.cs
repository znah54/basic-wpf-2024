﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace ex04_wpf_bikeshop.Logic
{
    internal class Bike
    {
        public double Speed { get; set; }
        public Color Color { get; set; }
    }
}
